from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any

from flask import Flask, jsonify, render_template, request, send_file


BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
BACKUP_DIR = BASE_DIR / "backups"
DB_PATH = DATA_DIR / "occmed.db"

DATA_DIR.mkdir(exist_ok=True)
BACKUP_DIR.mkdir(exist_ok=True)

app = Flask(__name__)


def get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with get_conn() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS records (
                record_id TEXT PRIMARY KEY,
                hn TEXT NOT NULL,
                patient_name TEXT,
                visit_date TEXT,
                visit_type TEXT,
                data_json TEXT NOT NULL,
                created_at TEXT,
                updated_at TEXT
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_records_hn ON records(hn)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_records_visit_date ON records(visit_date)")


def row_to_record(row: sqlite3.Row) -> dict[str, Any]:
    try:
        record = json.loads(row["data_json"])
    except json.JSONDecodeError:
        record = {}

    # Keep key fields queryable and visible even if old JSON is incomplete.
    record.setdefault("recordId", row["record_id"])
    record.setdefault("hn", row["hn"])
    record.setdefault("patientName", row["patient_name"] or "")
    record.setdefault("visitDate", row["visit_date"] or "")
    record.setdefault("visitType", row["visit_type"] or "")
    record.setdefault("createdAt", row["created_at"] or "")
    record.setdefault("updatedAt", row["updated_at"] or "")
    return record


@app.get("/")
def index():
    return render_template("index.html")


@app.get("/api/records")
def list_records():
    init_db()
    with get_conn() as conn:
        rows = conn.execute(
            """
            SELECT *
            FROM records
            ORDER BY hn ASC, visit_date DESC, updated_at DESC
            """
        ).fetchall()

    return jsonify({"records": [row_to_record(row) for row in rows]})


@app.post("/api/records/replace")
def replace_records():
    """Replace the SQLite contents with the current frontend state.

    This keeps the migration from the original localStorage app simple:
    the browser still edits an in-memory array, then sends the whole array here.
    For one offline computer, this is acceptable and easy to understand.
    """
    init_db()

    payload = request.get_json(silent=True) or {}
    records = payload.get("records", [])
    if not isinstance(records, list):
        return jsonify({"error": "records must be a list"}), 400

    now = datetime.utcnow().isoformat(timespec="seconds") + "Z"

    with get_conn() as conn:
        conn.execute("DELETE FROM records")

        for index, record in enumerate(records):
            if not isinstance(record, dict):
                continue

            record_id = str(record.get("recordId") or record.get("id") or f"visit_unknown_{index}_{now}")
            hn = str(record.get("hn") or "").strip()
            if not hn:
                continue

            patient_name = str(record.get("patientName") or "")
            visit_date = str(record.get("visitDate") or "")
            visit_type = str(record.get("visitType") or "")
            created_at = str(record.get("createdAt") or now)
            updated_at = str(record.get("updatedAt") or now)
            record["recordId"] = record_id
            record["createdAt"] = created_at
            record["updatedAt"] = updated_at

            conn.execute(
                """
                INSERT INTO records (
                    record_id, hn, patient_name, visit_date, visit_type,
                    data_json, created_at, updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    record_id,
                    hn,
                    patient_name,
                    visit_date,
                    visit_type,
                    json.dumps(record, ensure_ascii=False),
                    created_at,
                    updated_at,
                ),
            )

    return jsonify({"ok": True, "count": len(records)})


@app.get("/api/backup/json")
def backup_json():
    """Download all records as JSON backup."""
    init_db()
    with get_conn() as conn:
        rows = conn.execute("SELECT * FROM records ORDER BY hn ASC, visit_date DESC").fetchall()
    records = [row_to_record(row) for row in rows]
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = BACKUP_DIR / f"occmed_backup_{timestamp}.json"
    backup_path.write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8")
    return send_file(backup_path, as_attachment=True, download_name=backup_path.name)


@app.get("/api/backup/db")
def backup_db():
    """Download the raw SQLite database file."""
    init_db()
    return send_file(DB_PATH, as_attachment=True, download_name="occmed.db")


if __name__ == "__main__":
    init_db()
    app.run(host="127.0.0.1", port=8000, debug=True)
