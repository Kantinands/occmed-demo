# OccMed SQLite Local App

ระบบนี้พัฒนาต่อจาก HTML เดิม โดยเปลี่ยนจาก localStorage เป็น SQLite ที่เก็บในเครื่อง

## ไฟล์สำคัญ

- `app.py` = backend Flask
- `templates/index.html` = หน้าเว็บเดิมที่ปรับให้คุยกับ backend ผ่าน fetch()
- `data/occmed.db` = ฐานข้อมูล SQLite จะถูกสร้างอัตโนมัติเมื่อรัน
- `backups/` = โฟลเดอร์สำหรับไฟล์ backup JSON

## วิธีรันบน Windows

1. แตก zip
2. เข้าโฟลเดอร์ `occmed_sqlite_local_app`
3. ดับเบิลคลิก `start_windows.bat`
4. เปิด browser ที่ `http://127.0.0.1:8000`

## วิธีรันบน macOS/Linux

```bash
cd occmed_sqlite_local_app
chmod +x start_mac_linux.sh
./start_mac_linux.sh
```

แล้วเปิด `http://127.0.0.1:8000`

## จุดที่เปลี่ยนจาก localStorage

ใน HTML เดิม:

```js
localStorage.getItem(...)
localStorage.setItem(...)
```

ถูกเปลี่ยนเป็น:

```js
fetch('/api/records')
fetch('/api/records/replace')
```

ข้อมูลจึงถูกเก็บใน `data/occmed.db`

## Backup

สามารถดาวน์โหลดข้อมูลทั้งหมดได้จาก:

- `http://127.0.0.1:8000/api/backup/json`
- `http://127.0.0.1:8000/api/backup/db`

## หมายเหตุ

ไฟล์นี้ยังเป็น prototype สำหรับใช้งาน local/offline ในเครื่องเดียว ยังไม่มี login, encryption, audit log และ role-based access control
